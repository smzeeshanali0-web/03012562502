package com.olxchat

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.util.Base64
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var etUrls: EditText
    private lateinit var etStart: EditText
    private lateinit var etEnd: EditText
    private lateinit var etMsg: EditText
    private lateinit var tvLog: TextView
    private lateinit var tvPic: TextView
    private lateinit var tvState: TextView
    private lateinit var btnPause: Button

    private var running = false
    private var paused = false
    private var picUri: Uri? = null
    private var imgData: String? = null
    @Volatile private var picked = false
    private var pending: CompletableDeferred<String>? = null
    private var loaded: CompletableDeferred<Unit>? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var defaultUa = ""
    private val desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val prefs by lazy { getSharedPreferences("olx", MODE_PRIVATE) }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@registerForActivityResult
        picUri = uri
        tvPic.text = "Picture: tayyar ho rahi hai..."
        lifecycleScope.launch {
            val d = withContext(Dispatchers.IO) { prepareImage(uri) }
            imgData = d
            tvPic.text = if (d != null) "Picture: selected" else "Picture: load nahi hui"
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun result(s: String) { pending?.complete(s) }

        @JavascriptInterface
        fun wasPicked(): Boolean = picked
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12) }

        etUrls = EditText(this).apply { hint = "Category URLs (har line mein 1)"; minLines = 3; textSize = 12f }
        etStart = EditText(this).apply { hint = "Start page"; inputType = 2 }
        etEnd = EditText(this).apply { hint = "End page"; inputType = 2 }
        etMsg = EditText(this).apply { minLines = 2; textSize = 12f }
        etUrls.setText(prefs.getString("urls", ""))
        etStart.setText(prefs.getString("sp", "1"))
        etEnd.setText(prefs.getString("ep", "2"))
        etMsg.setText(prefs.getString("msg", "Salam, kya yeh available hai? Mujhse rabta karein."))

        val pages = LinearLayout(this)
        pages.addView(etStart, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        pages.addView(etEnd, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))

        val cbDesktop = CheckBox(this).apply { text = "Desktop site mode"; isChecked = true; textSize = 12f }

        fun mkBtn(t: String) = Button(this).apply { text = t; textSize = 11f; isAllCaps = false }
        val btnLogin = mkBtn("Login")
        val btnPic = mkBtn("Pic chunein")
        val btnNoPic = mkBtn("Pic hatao")
        val btnStart = mkBtn("Start")
        btnPause = mkBtn("Pause")
        val btnStop = mkBtn("Stop").apply { setTextColor(Color.RED) }
        val btnClear = mkBtn("History clear")
        val btnBattery = mkBtn("Battery allow")

        fun row(vararg bs: Button): LinearLayout {
            val r = LinearLayout(this)
            bs.forEach { r.addView(it, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)) }
            return r
        }

        tvPic = TextView(this).apply { text = "Picture: none"; textSize = 11f }
        tvState = TextView(this).apply { text = "Status: Idle"; textSize = 13f; setTextColor(Color.parseColor("#002f34")) }
        tvLog = TextView(this).apply { textSize = 11f }

        panel.addView(etUrls)
        panel.addView(pages)
        panel.addView(etMsg)
        panel.addView(cbDesktop)
        panel.addView(row(btnLogin, btnPic, btnNoPic))
        panel.addView(tvPic)
        panel.addView(row(btnStart, btnPause, btnStop))
        panel.addView(row(btnClear, btnBattery))
        panel.addView(tvState)
        panel.addView(tvLog)
        val scroll = ScrollView(this).apply { addView(panel) }

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.settings.builtInZoomControls = true
        web.settings.displayZoomControls = false
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        defaultUa = web.settings.userAgentString
        web.settings.userAgentString = desktopUa
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) { loaded?.complete(Unit) }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView?,
                cb: ValueCallback<Array<Uri>>?,
                p: WebChromeClient.FileChooserParams?
            ): Boolean {
                val u = picUri
                if (u != null) {
                    picked = true
                    cb?.onReceiveValue(arrayOf(u))
                } else {
                    cb?.onReceiveValue(null)
                }
                return true
            }
        }
        web.loadUrl("https://www.olx.com.pk")

        root.addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        root.addView(web, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1.4f))
        setContentView(root)

        cbDesktop.setOnCheckedChangeListener { _, on ->
            web.settings.userAgentString = if (on) desktopUa else defaultUa
            web.reload()
        }
        btnLogin.setOnClickListener {
            web.loadUrl("https://www.olx.com.pk")
            log("WebView mein OLX par login karein, phir Start dabayein.")
        }
        btnPic.setOnClickListener { pickImage.launch("image/*") }
        btnNoPic.setOnClickListener { picUri = null; imgData = null; tvPic.text = "Picture: none" }
        btnClear.setOnClickListener { prefs.edit().remove("sent").apply(); log("Sent history clear ho gayi.") }
        btnBattery.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + packageName)))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        btnStart.setOnClickListener { if (!running) start() else log("Pehle se chal raha hai.") }
        btnPause.setOnClickListener {
            if (!running) return@setOnClickListener
            paused = !paused
            btnPause.text = if (paused) "Resume" else "Pause"
            setState(if (paused) "Pause hoga (current ad ke baad)..." else "Running")
        }
        btnStop.setOnClickListener {
            if (!running) return@setOnClickListener
            running = false
            paused = false
            pending?.complete("")
            loaded?.complete(Unit)
            setState("Stopping...")
        }
    }

    override fun onPause() {
        super.onPause()
        if (running) web.resumeTimers()
    }

    override fun onStop() {
        super.onStop()
        if (running) web.resumeTimers()
    }

    private fun log(s: String) {
        runOnUiThread { tvLog.text = (s + "\n" + tvLog.text.toString()).take(3000) }
    }

    private fun setState(s: String) {
        runOnUiThread { tvState.text = "Status: " + s }
    }

    private fun prepareImage(uri: Uri): String? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val maxSide = 1280
            val scale = minOf(1f, maxSide.toFloat() / maxOf(bmp.width, bmp.height))
            val out = if (scale < 1f) {
                Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
            } else bmp
            val bos = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun navigate(url: String) {
        loaded = CompletableDeferred()
        web.loadUrl(url)
        withTimeoutOrNull(25000) { loaded!!.await() }
        delay(3500)
    }

    private suspend fun runJs(script: String, timeout: Long): String {
        pending = CompletableDeferred()
        web.evaluateJavascript(script, null)
        return withTimeoutOrNull(timeout) { pending!!.await() } ?: ""
    }

    private suspend fun checkpoint(): Boolean {
        if (paused && running) setState("Paused - Resume dabayein")
        while (paused && running) delay(500)
        if (running) setState("Running")
        return running
    }

    private fun acquireWake() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "olxchat:run")
            wakeLock?.acquire(6 * 60 * 60 * 1000L)
        } catch (e: Exception) { }
    }

    private fun releaseWake() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (e: Exception) { }
    }

    private fun start() {
        val cats = etUrls.text.toString().lines().map { it.trim() }.filter { it.contains("olx.com.pk") }
        val sp = etStart.text.toString().toIntOrNull() ?: 1
        val ep = etEnd.text.toString().toIntOrNull() ?: 1
        val msg = etMsg.text.toString().trim()
        if (cats.isEmpty() || msg.isEmpty() || sp < 1 || sp > ep) {
            log("Valid URLs, message aur page range daalein.")
            return
        }
        prefs.edit()
            .putString("urls", etUrls.text.toString())
            .putString("sp", etStart.text.toString())
            .putString("ep", etEnd.text.toString())
            .putString("msg", msg)
            .apply()

        running = true
        paused = false
        btnPause.text = "Pause"
        setState("Running")
        ContextCompat.startForegroundService(this, Intent(this, KeepAliveService::class.java))
        acquireWake()

        lifecycleScope.launch {
            try {
                val sent = prefs.getStringSet("sent", emptySet())!!.toMutableSet()
                outer@ for (cat in cats) {
                    val base = cat.substringBefore("?")
                    for (page in sp..ep) {
                        if (!checkpoint()) break@outer
                        log("Page " + page + ": " + base)
                        navigate(base + "?page=" + page)
                        var urls = parseUrls(runJs(LINKS_JS, 20000))
                        if (urls.isEmpty()) {
                            delay(4000)
                            urls = parseUrls(runJs(LINKS_JS, 20000))
                        }
                        val fresh = urls.filter { it !in sent }
                        var n = 0
                        for (u in fresh) {
                            if (!checkpoint()) break@outer
                            n++
                            navigate(u)
                            picked = false
                            val img = imgData
                            val script = CHAT_JS
                                .replace("__MSG__", JSONObject.quote(msg))
                                .replace("__IMG__", if (img != null) JSONObject.quote(img) else "null")
                            val raw = runJs(script, 90000)
                            val status = try { JSONObject(raw).getString("status") } catch (e: Exception) { "No response" }
                            val title = try { JSONObject(raw).getString("title").take(30) } catch (e: Exception) { u }
                            log("[" + n + "/" + fresh.size + "] " + title + " -> " + status)
                            if (status.contains("Sent")) {
                                sent.add(u)
                                prefs.edit().putStringSet("sent", sent).apply()
                            }
                            delay(3000 + (Math.random() * 3000).toLong())
                        }
                    }
                }
                log("Finished / stopped.")
            } finally {
                running = false
                paused = false
                stopService(Intent(this@MainActivity, KeepAliveService::class.java))
                releaseWake()
                setState("Idle")
                btnPause.text = "Pause"
            }
        }
    }

    private fun parseUrls(raw: String): List<String> {
        return try {
            val a = JSONArray(raw)
            val out = ArrayList<String>()
            for (i in 0 until a.length()) out.add(a.getString(i))
            out
        } catch (ex: Exception) {
            emptyList()
        }
    }

    companion object {
        const val LINKS_JS = """
(async function(){
  const wait=ms=>new Promise(r=>setTimeout(r,ms));
  for(let i=0;i<4;i++){window.scrollBy(0,1500);await wait(700);}
  const urls=[];
  document.querySelectorAll('a[href*="/item/"]').forEach(a=>{
    const h=a.getAttribute('href'); if(!h) return;
    let f=h.startsWith('http')?h:'https://www.olx.com.pk'+h;
    f=f.split('?')[0]; if(!urls.includes(f)) urls.push(f);
  });
  Android.result(JSON.stringify(urls));
})();
"""
        const val CHAT_JS = """
(async function(){
  const wait=ms=>new Promise(r=>setTimeout(r,ms));
  let title='Unknown Title', price='N/A', status='Chat Failed';
  const IMG=__IMG__;
  const ATT='M537.07 92.46';
  function done(){Android.result(JSON.stringify({title:title,price:String(price),status:status}));}
  function findSend(){
    const c=Array.from(document.querySelectorAll('button,[role="button"],[data-aut-id*="send"]'));
    for(const el of c){
      if(el.innerHTML&&el.innerHTML.includes(ATT)) continue;
      const t=((el.innerText||'')+' '+(el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')+' '+(el.getAttribute('data-aut-id')||'')).toLowerCase();
      if(t.includes('send')) return el;
    }
    return null;
  }
  try{
    const s=document.querySelector('script[type="application/ld+json"]');
    if(s){const j=JSON.parse(s.innerText); if(j.name) title=j.name;
      if(j.offers) price=Array.isArray(j.offers)?(j.offers[0].price||'N/A'):(j.offers.price||'N/A');}
  }catch(e){}
  if(title==='Unknown Title'){const h=document.querySelector('h1'); if(h) title=h.innerText;}
  try{
    const all=Array.from(document.querySelectorAll('button, a, span'));
    const chatBtn=all.find(b=>{
      const t=(b.innerText||'').toLowerCase().trim();
      const a=(b.getAttribute('aria-label')||'').toLowerCase().trim();
      return t.includes('chat')||a.includes('chat');
    });
    if(!chatBtn){status='Chat Hidden';done();return;}
    chatBtn.click(); await wait(4000);
    const input=document.querySelector('textarea')||
      document.querySelector('input[placeholder*="message" i]')||
      document.querySelector('input[placeholder*="Write" i]')||
      document.querySelector('div[contenteditable="true"]')||
      document.querySelector('div[role="textbox"]');
    if(!input){status='Field Blocked / Not Logged In';done();return;}
    input.focus(); input.click(); await wait(500);
    const msg=__MSG__;
    if(input.isContentEditable){input.textContent=msg; input.dispatchEvent(new Event('input',{bubbles:true}));}
    else{
      const proto=input.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto,'value').set.call(input,msg);
      input.dispatchEvent(new Event('input',{bubbles:true}));
      input.dispatchEvent(new Event('change',{bubbles:true}));
    }
    await wait(1200);
    const sendBtn=findSend();
    if(sendBtn){sendBtn.click(); status='Message Sent';}
    else{
      const o={key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true};
      input.dispatchEvent(new KeyboardEvent('keydown',o));
      input.dispatchEvent(new KeyboardEvent('keypress',o));
      input.dispatchEvent(new KeyboardEvent('keyup',o));
      status='Sent (Enter)';
    }
    await wait(2000);

    if(IMG){
      let handled=false;
      const origClick=HTMLInputElement.prototype.click;
      const origPicker=HTMLInputElement.prototype.showPicker;
      let cap=null;
      try{
        const mime=IMG.substring(5,IMG.indexOf(';'));
        const bin=atob(IMG.split(',')[1]);
        const bytes=new Uint8Array(bin.length);
        for(let i=0;i<bin.length;i++) bytes[i]=bin.charCodeAt(i);
        const file=new File([bytes],'photo.jpg',{type:mime||'image/jpeg'});
        const applyTo=(inp)=>{
          const dt=new DataTransfer(); dt.items.add(file); inp.files=dt.files;
          inp.dispatchEvent(new Event('input',{bubbles:true}));
          inp.dispatchEvent(new Event('change',{bubbles:true}));
          handled=true;
        };
        HTMLInputElement.prototype.click=function(){
          if(this.type==='file'){applyTo(this);return;}
          return origClick.apply(this,arguments);
        };
        if(origPicker){
          HTMLInputElement.prototype.showPicker=function(){
            if(this.type==='file'){applyTo(this);return;}
            return origPicker.apply(this,arguments);
          };
        }
        cap=(e)=>{
          const t=e.target; let inp=t.closest&&t.closest('input[type="file"]');
          if(!inp&&t.closest){const lb=t.closest('label'); if(lb&&lb.control&&lb.control.type==='file') inp=lb.control;}
          if(inp){e.preventDefault(); applyTo(inp);}
        };
        document.addEventListener('click',cap,true);

        const findPath=(r)=>Array.from(r.querySelectorAll('path')).find(p=>(p.getAttribute('d')||'').startsWith(ATT))||null;
        let icon=null; let scope=input;
        for(let i=0;i<8&&scope&&!icon;i++){scope=scope.parentElement; if(scope) icon=findPath(scope);}
        if(!icon) icon=findPath(document);
        let target=null;
        if(icon) target=icon.closest('button,[role="button"],label,a')||icon.closest('svg').parentElement;
        if(!target){
          target=Array.from(document.querySelectorAll('button,[role="button"],label,[data-aut-id]')).find(el=>{
            const t=((el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')+' '+(el.getAttribute('data-aut-id')||'')).toLowerCase();
            return /attach|upload|photo|image|clip/.test(t);
          })||null;
        }
        if(target){target.click(); await wait(2500);}
        if(!handled){const fi=document.querySelector('input[type="file"]'); if(fi) applyTo(fi); await wait(1500);}
        if(!handled && Android.wasPicked()) handled=true;
        if(handled){
          await wait(2500);
          const b2=findSend();
          if(b2) b2.click();
          await wait(2000);
          status+=' + Pic';
        } else { status+=' (Pic attach nahi hui)'; }
      }catch(e){ status+=' (Pic error)'; }
      finally{
        HTMLInputElement.prototype.click=origClick;
        if(origPicker) HTMLInputElement.prototype.showPicker=origPicker;
        if(cap) document.removeEventListener('click',cap,true);
      }
    }
  }catch(e){status='Error';}
  done();
})();
"""
    }
}
